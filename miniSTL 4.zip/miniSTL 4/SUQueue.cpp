/*
 *==============================================
 *SUQueueArr Functions
 *==============================================
*/

/*
 *incCapacity function will be called from the enqueue function. If the capacity is reached incCapacity
 *will be called. This function will allocate a new array with double the capacity and copy the old array
 *into the newly created array and deletes the old array
 *Author: Max Camm
*/
 template <class T>
 void SUQueueArr<T>::incCapacity(){

 	T* oldArray = arr;
 	capacity *= 2;
 	arr = new T[capacity];

 	for(int i = 0; i < rear; i++){
 		arr[i] = oldArray[i];
 	}

 	delete[] oldArray;
 }

 /*
  *SUQueueArr default constructor
  *sets arr to a empty array with capacity 10
  *sets front = -1
  *sets rear = 0
  * Author: Max Camm
 */
template <class T>
SUQueueArr<T>::SUQueueArr() {

	capacity = 10;
	front = -1;
	rear = 0;
	arr = new T[capacity];
}

/*
 *SUQueueArr copy constructor sets the front and rear member variables to &obj(SUQueueArr obj passed by reference)
 *and uses a for loop to copy the array items from &obj into the new SUQueueArr array
 *Author: Sam Barnes
*/
template <class T>
SUQueueArr<T>::SUQueueArr(const SUQueueArr &obj) {

	arr = new T[obj.capacity];
	front = obj.front;
	rear = obj.rear;
	for(int i = 0; i < rear ; i++){
		arr[i] = obj.arr[i];
	}

}


/*
 *SUQueueArr destructor deallocates memory held by SUQueueArr
 *it is implicitly called at the end of the program releasing memory
 *Author: Max Camm
*/
template <class T>
SUQueueArr<T>::~SUQueueArr() {

}


/*
 *size function returns an int value
 *returns the int value from rear member variable because rear always points to the last element of the array
 *Author: Max Camm
*/
template <class T>
int SUQueueArr<T>::size() const{
	int size;
	size = rear - (front + 1);
	return size;
}

/*
 *isEmpty returns a boolean value for true if rear member variable is not 0 signifying that the arr
 *is not empty. returns boolean value false if rear = 0
 *Author: Sam Barnes
*/
template <class T>
bool SUQueueArr<T>::isEmpty() const {
	bool state;
	if(rear != 0)
		state = false;
	else
		state = true;
	return state;
}


/*
 *enqueue function will take a template value passed as reference as an argument
 *sets the array element at arr[rear] to argument value and increments rear variable to point to the next available element
 *if the rear variable + 1 = capacity then incCapacity is called to allocate more space in the array
 *Author: Max Camm
*/
template <class T>
void SUQueueArr<T>::enqueue(const T &item) {


	if(rear + 1 == capacity){
		arr[rear] = item;
		rear++;
		incCapacity();
		//rear--;
	}
	else{
		arr[rear] = item;
		rear++;
	}

}

/*
 *dequeue function takes a template value passed as reference as an argument
 *if the queue is empty prints a statement letting the user know that the queue is empty
 *if the queue is not empty then it sets the argument to the front element in the array
 *and increments front by 1
 *Author: Max Camm
*/
template <class T>
void SUQueueArr<T>::dequeue(T &item) {

	if(isEmpty()) {
		std::cout << "The queue is empty\n";
	}
	else{
		front++;
		item = arr[front];
	}
}

/*
 *printQueue function will print out all the elements of the array
 *sets int variable x to the size of the array using the size function
 *a for loop from 0 to x will print out all of the elements of the array
 *Author: Max Camm
*/
template <class T>
void SUQueueArr<T>::printQueue() const {

	int x = rear;
	//std::cout << "ARRAY SIZE: " << x << std::endl;

	std::cout << "===============\n";
	for(int i = front + 1; i < x; i++){
		std::cout << arr[i] << std::endl;
	}
	std::cout << "================\n";
	//WORKS
}


/*
 *==============================================
 *SUQueueList Functions
 *==============================================
*/


/*
 *Default constructor for SUQueueList, initializes the private member variable
 *of SUList to an empty linked list with head pointed to nullptr.
 *
 *Author: Max Camm
 *
*/
template <class T>
SUQueueList<T>::SUQueueList() {
	list;
}


/*
 *Copy Constructor copies the SUList member variable of another SUQueueList object,
 *which is passed by reference(SUQueueList<T> &other). this reference variable is also const
 *so the constructor cannot alter the list of the passed SUQueueList
 *Author: Max Camm
*/
template <class T>
SUQueueList<T>::SUQueueList(const SUQueueList<T> &other) {
	list = other.list;
}


/*
 *SUQueueList Destructor deallocates memory held by an SUQueueList
 *will be implicitly called and end of program
 *Author: Max Camm
 *
*/
template <class T>
SUQueueList<T>::~SUQueueList() {

}


/*
 *Assignment operator overload for SUQueueList, will first delete whatever memory is held in the SUQueuelist
 *that called it, then copy the list object of the argument passed by
 *reference. argument is const so the function 
 *cannot alter SUQueueList passed
 *Author: Max Camm
*/
template<class T>
SUQueueList<T>& SUQueueList<T>::operator=(const SUQueueList<T>& other){
	list.~SUList();
	list = other.list;
}


/*
 *size function calls the const function size of SUList, which returns an integer. The integer
 *is stored in int variable x, function returns int variable x.
 *
 *Author: Sam Barnes
*/
template <class T>
int SUQueueList<T>::size() const{
	int x = list.size(); //stores size of SUList list
	return x; // returns int value size of the Queue
}


/*
 *isEmpty calls SUQueueList function size to determine how many nodes are in the Queue
 *an if statement determines if the size of the Queue is 0 or not. If Queue size is 0 and the queue is empty
 *the function returns the boolean value true, if the Queue size > 0 and has nodes returns 
 *boolean value false;
 *Author: Sam Barnes
*/
template <class T>
bool SUQueueList<T>::isEmpty() const{
	int x = size(); //stores size of queue in x
	if(x == 0)		//checks to see if size = 0
		return true;//returns true if queue is empty
	else
		return false;//returns false if queue is not empty
}


/*
 *enqueue function takes a const template value passed by reference. Places the value in a node to
 *the front of the queue by calling the putFront function from the SUQueueList list member variable.
 *Author: Same Barnes
*/
template <class T>
void SUQueueList<T>::enqueue(const T &item) {
	list.putFront(item);
}


/*
 *dequeue function passes an const template value by reference. dequeue will remove the last node
 *in the queue and store the template value of that node into the argument variable that was passed
 *by reference
 *Author: Sam Barnes
*/
template <class T>
void SUQueueList<T>::dequeue(T &item) {
	item = list.getBack();
}


/*
 *printQueue function will cycle through the Queue and print out the values stored in each node.
 *printQueue creates a new temporary SUQueueList called copyList so that the list from the called object
 *does not become altered. copyList uses the SUList assignment operator so it has a direct copy of the list
 *variable. The while loop will run until the queue is empty using the boolean function isEmpty, it will
 *remove and print from the back of the queue until the queue is empty. 
*/
template <class T>
void SUQueueList<T>::printQueue() const{

	SUQueueList<T> copyList;//creates a new SUQueue list
	copyList.list = list;	//copies list function into copyList

	std::cout << "==========================\n";

	while(!copyList.isEmpty()){//runs until copyList is empty
		std::cout << copyList.list.getBack() << std::endl; //removes a node and prints its value on every iteration
		std::cout << "==========================\n";	   
	}

}