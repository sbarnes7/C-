#include<iostream>
#include "SUList.h"
#include "SUStack.h"
#include "PayRoll.h"
#include "SUQueue.h"

/**
 * This program provides a slightly-more-than-minimal
 * example of a program that makes use of the various
 * classes defined in the SULibrary project.
 *
 * It only runs partial tests for three of the classes.
 * You should write more on your own, but this can
 * server as a sanity-check to get started.
 *
 * Be sure to think about edge cases!
 */

int main(){

  /*
   * First, make sure our templates are available.
   */

  SUList<int> myList;
  SUList<PayRoll> pList;

  SUStackArr<int> iStackArr;
  SUStackArr<PayRoll> pStackArr;
  SUStackList<int> iStackList;
  SUStackList<PayRoll> pStackList;

  SUQueueArr<int> iQueueArr;
  SUQueueArr<PayRoll> pQueueArr;
  SUQueueList<int> iQueueList;
  SUQueueList<PayRoll> pQueueList;

  /**
   * Test the SUList using ints
   */
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n\n";


  myList.putFront(1);
  myList.putFront(2);
  myList.putBack(3);
  myList.putBack(4);
  myList.putFront(5);

  bool tf;

  tf = myList.contains(8);
  std::cout << "CONTAINS: ";
  std::cout << tf << std::endl;


  std::cout << "==========================\n";
  std::cout << "SUList<int> size: " << myList.size() << std::endl;


  std::cout << myList.getFront() << std::endl;
  std::cout << myList.getFront() << std::endl;
  std::cout << myList.getBack() << std::endl;
  std::cout << myList.getBack() << std::endl;
  std::cout << myList.getBack() << std::endl;






  /**
   * Test the SUList using PayRoll
   */
  pList.putFront(PayRoll("Bob", 20, 35));
  pList.putFront(PayRoll("Alice", 10, 35));
  pList.putBack(PayRoll("Charlie", 25, 35));
  pList.putBack(PayRoll("Diana", 10, 35));
  pList.putFront(PayRoll("Eve", 30, 35));

  bool pt;


  std::cout << "==========================\n";
  std::cout << "\n\nSUList<PayRoll> size: " << pList.size() << std::endl;

  pt = pList.contains(PayRoll("Bob", 20, 35));
  std::cout << "CONTAINS: ";
  std::cout << pt << std::endl;
  //uses getFront and getBack to test if putFront and putBack functions are working properly
  std::cout << "pList<PayRoll> Front: \n" << pList.getFront() << std::endl;
  std::cout << "pList<PayRoll> Back: \n" << pList.getBack() << std::endl;




  /*
   * Test the SUStack using PayRoll
  */
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";

   iStackList.push(1);
   iStackList.push(2);
   iStackList.push(3);
   iStackList.push(4);
   iStackList.push(5);
   iStackList.push(6);


  std::cout << "==========================\n";
  std::cout << "SUStackList<int> size: " << iStackList.size() << std::endl;
  iStackList.printStack();


  pStackList.push(PayRoll("Bob", 20, 35));
  pStackList.push(PayRoll("Alice", 20, 35));
  pStackList.push(PayRoll("Charlie", 20, 35));
  pStackList.push(PayRoll("Diana", 20, 35));
  pStackList.push(PayRoll("Eve", 20, 35));



  std::cout << "==========================\n";
   std::cout << "\n\nSUStackList<PayRoll> size: " << pStackList.size() << std::endl;
  pStackList.printStack();



  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";

  int num;
  iQueueList.enqueue(1);
  iQueueList.enqueue(2);
  iQueueList.enqueue(3);
  iQueueList.enqueue(4);
  iQueueList.enqueue(5);
  iQueueList.dequeue(num);
  iQueueList.dequeue(num);
  iQueueList.dequeue(num);
  iQueueList.enqueue(1);
  iQueueList.enqueue(2);
  iQueueList.enqueue(3);

  std::cout << "==========================\n";
  std::cout << "SUQueueList<int> size: " << iQueueList.size() << std::endl;

  iQueueList.printQueue();

  pQueueList.enqueue(PayRoll("Bob", 20, 35));
  pQueueList.enqueue(PayRoll("Alice", 20, 35));
  pQueueList.enqueue(PayRoll("Charlie", 20, 35));
  pQueueList.enqueue(PayRoll("Diana", 20, 35));
  pQueueList.enqueue(PayRoll("Eve", 20, 35));

  std::cout << "\n\n\n==========================\n";
  std::cout << "SUQueueList<PayRoll> size: " << iQueueList.size() << std::endl;
  
  pQueueList.printQueue();
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n\n";


  int x;
  iQueueArr.dequeue(x);
  iQueueArr.enqueue(1);
  iQueueArr.enqueue(2);
  iQueueArr.enqueue(3);
  iQueueArr.enqueue(4);
  iQueueArr.enqueue(5);
  iQueueArr.enqueue(6);
  iQueueArr.enqueue(7);
  iQueueArr.enqueue(8);
  iQueueArr.enqueue(9);
  iQueueArr.enqueue(10);
  iQueueArr.enqueue(11);
  iQueueArr.enqueue(12);
  iQueueArr.enqueue(13);
  iQueueArr.enqueue(14);
  iQueueArr.enqueue(15);
  iQueueArr.enqueue(16);
  iQueueArr.enqueue(17);
  iQueueArr.enqueue(18);
  iQueueArr.enqueue(19);
  iQueueArr.enqueue(20);
  iQueueArr.enqueue(21);
  iQueueArr.dequeue(x);
  iQueueArr.dequeue(x);
  iQueueArr.dequeue(x);
  iQueueArr.dequeue(x);
  std::cout << "x: " << x << std::endl;

  std::cout << "SUQueueArr<int> " << iQueueArr.size() << std::endl;
  iQueueArr.printQueue();
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n\n";

  PayRoll p;
  pQueueArr.enqueue(PayRoll("Bob", 20, 35));
  pQueueArr.enqueue(PayRoll("Alice", 20, 35));
  pQueueArr.enqueue(PayRoll("Charlie", 20, 35));
  pQueueArr.enqueue(PayRoll("Diana", 20, 35));
  pQueueArr.enqueue(PayRoll("Eve", 20, 35));
  pQueueArr.dequeue(p);
  std::cout << "Dequeued:\n" << p << std::endl;


  std::cout << "SUQueueArr<PayRoll> size: " << pQueueArr.size() << std::endl;
  pQueueArr.printQueue();

  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n\n";
  //Testing done for copy ctor and operator overload on SUQueueArr<int>
  /*SUQueueArr<int> copyArr;
  copyArr.enqueue(2);
  copyArr.enqueue(2);
  copyArr.enqueue(2);
  copyArr.enqueue(2);
  copyArr.enqueue(2);
  copyArr = iQueueArr;
  copyArr.printQueue();*/

  std::cout << "================\n\n\n";


  int k;
  iStackArr.pop(k);
  iStackArr.push(1);
  iStackArr.push(2);
  iStackArr.push(3);
  iStackArr.push(4);
  iStackArr.push(5);
  iStackArr.push(6);
  iStackArr.push(7);
  iStackArr.push(8);
  iStackArr.push(9);
  iStackArr.push(10);
  iStackArr.push(11);
  iStackArr.push(12);
  iStackArr.push(13);
  iStackArr.push(14);
  iStackArr.push(15);
  iStackArr.push(16);
  iStackArr.push(17);
  iStackArr.push(18);
  iStackArr.push(19);
  iStackArr.push(20);
  iStackArr.push(21);
  iStackArr.pop(k);
  iStackArr.pop(k);
  iStackArr.pop(k);
  iStackArr.pop(k);

  std::cout << "SUStackArr<int> " << iStackArr.size() << std::endl;
  iStackArr.printStack();


  //testing done for copy ctor and operator overload on SUStackArr<int>
  /*SUStackArr<int> copyArr;
  copyArr.push(2);
  copyArr.push(2);
  copyArr.push(2);
  copyArr.push(2);
  copyArr = iStackArr;
  copyArr.printStack();*/
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n\n";


  PayRoll temp;
  pStackArr.push(PayRoll("Bob", 20, 35));
  pStackArr.push(PayRoll("Alice", 20, 35));
  pStackArr.push(PayRoll("Charlie", 20, 35));
  pStackArr.push(PayRoll("Diana", 20, 35));
  pStackArr.push(PayRoll("Eve", 20, 35));
  pStackArr.pop(temp);
  std::cout <<"Dequeued:\n" << temp << std::endl;

  std::cout << "SUStackArr<PayRoll> size: " << pStackArr.size() << std::endl;
  pStackArr.printStack();







  std::cout << "END MAIN" << std::endl;
  return 0;


}

/** OUTPUT OF THIS PROGRAM

3
2
6
1
4
5
++++++++++++
=======================
Name: Eve
Rate: 35
Hours:	30
Total:	1050

=======================
Name:	Alice
Rate:	35
Hours:	10
Total:	350

=======================
Name:	Bob
Rate:	35
Hours:	20
Total:	700

=======================
Name:	Charlie
Rate:	35
Hours:	25
Total:	875

=======================
Name:	Diana
Rate:	35
Hours:	10
Total:	350

++++++++++++
=======================
Name:	Eve
Rate:	35
Hours:	20
Total:	700

*/
