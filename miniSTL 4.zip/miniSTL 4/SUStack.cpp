//Sam Barnes and Max Camm
/********************************************************
//Template for the Stacks that uses arrays and lists    *
//for a simple push and pop implementation using the    *
//list template we created for this project as well.    *
********************************************************/


/*
 *======================================
 *SUStackList functions
 *======================================
*/

//Author: Sam Barnes
//The simple constructor for the list based constructor
//templates the overloaded function using variable type T
template <class T>
SUStackList<T>::SUStackList() {
	list;
}
//Author: Sam Barnes
//a copy constructor to create a second stack that can be set
//equal to the curtrent stack templates the copy constructor 
//function using variable type T
template <class T>
SUStackList<T>::SUStackList(const SUStackList<T>& other){
	list = other.list;
}
//Author: Sam Barnes
//the destructor for the list based stack that can delete the
//data once the  program is finished running templates the 
//overloaded function using variable type T
template <class T>
SUStackList<T>::~SUStackList() {

}
//Author: Sam Barnes
//overloaded assignment operator for the stack list
//templates the overloaded function using variable type T
template <class T>
SUStackList<T>& SUStackList<T>::operator=(const SUStackList<T>& other){
  //uses the list object to set your current list to the same as 
	//a list from the function
	list = other.list;
}
//Author: Sam Barnes
//size function for the list backed stack that asks the list template
//for the size in sulist and return that number
//templates the overloaded function using variable type T
template <class T>
int SUStackList<T>::size() const{
  	//creates a variable and sets it equal to the returned number in size of SULis
	int x = list.size();
	//returns the number passed in from sulist size function
	return x;
}
//Author: Sam Barnes
//function to test if the stack is currently empty using boolean
//and the size function templates the overloaded function using 
//variable type T
template <class T>
bool SUStackList<T>::isEmpty(){
  //creates variable to hold the number returned from size
	int num = 0;
	//calls the size function from list and stores that value in num
	num = list.size();
	//if num = 0 return true or is empty
	if(num ==0)
		return true;
	else
		return false;
	//otherwise return false
}
//Author: Sam Barnes
//function to push a data type onto the stack using the putfront 
//from the list template void function
//templates the overloaded function using variable type T
template <class T>
void SUStackList<T>::push(const T &num) {
  //uses the object for the list template and calls the putfront function to add
	//a variable to the front or in this case the top of the stack
	list.putFront(num);
}
//Author: Sam Barnes
//void function that pops a data type off of the stack uses the 
//list getfront function and sets the num that is passed into the
//fucntion equal to what is returned from the  list.getback function
//templates the pop function with a vraiable of type T
template <class T>
void SUStackList<T>::pop(T &num){
  //calling the getback function from list and setting the num passed in equal to what
  //get back is supposed to return
	num = list.getFront();
}
//Author: Max Camm
//a void function that does not return anything. The function is
//used to print the numbers off the stack from front to back of the
//stack using a while loop that steps through the list until it reaches
//the back of the list
//templates the print stack function with variable of type T
template <class T>
void SUStackList<T>::printStack(){
	//creating another list that is going to be equal to the first list
	SUStackList<T> copyList;
	//setting the new list equal to the first list
	copyList.list = list;
	  
	std::cout << "==========================\n";
	 //loops through the list from beginning until the end of the list printing elements
	//from copylist thats in the front of this list
	while(!copyList.isEmpty()){
		std::cout << copyList.list.getFront() << std::endl;
		std::cout << "==========================\n";
	}

}




/*
 *======================================
 *SUStackArr functions
 *======================================
*/

/*Author: Sam Barnes
 * This function is the constructor and does not take any arguments or return anything.
 * The functionality is to simply initialize all the variables being used.
 */
template <class T>//templates the constructor
SUStackArr<T>::SUStackArr() {
	top = -1;//sets top = to -1
	capacity = 10;//sets capacity to a random high number
	arr = new T[capacity];//intializes the dynamic array
	}
/*Author: Sam Barnes
 *This function is the copy constructor and is used to copy the data from the first
 *list into a second list. Takes a object and returns the object pointer.*/	
template <class T>//templates the copy constructor
SUStackArr<T>::SUStackArr(const SUStackArr &obj) {

	arr = new T[obj.capacity];
	top = obj.top;
	for(int i = 0; i < size() - 1; i++){
		arr[i] = obj.arr[i];
	}

}
/*Author: Sam Barnes
 * This functuion is the stack arrays destructor. It deletes the data and frees the 
 * memory as soon as it is done being used completely.*/
template <class T>//templates the destructor
SUStackArr<T>::~SUStackArr() {

}

/*Author: Sam Barnes
 * This function checks to see if the stack array is empty or not.
 * It is a boolean function and returns true if the top is equal to
 * -1 and false if it is not.*/
template <class T>//templates the empty function
bool SUStackArr<T>::isEmpty() {
	bool status;//creates a boolean variable
	if(top == -1)//if stack is empty
		status = true;//makes status true
	else//otherwise
		status = false;//makes status false
	return status;//returns the status
}
/*Author: Sam Barnes
 * This function is the push function and its job is to add data to the front of the 
 * array and move the rest of the data down to the next spot in the array. It does not
 * return anything and it takes an item with data as the parameter.*/
template <class T>//templates the push function
void SUStackArr<T>::push(const T &item) {
  if(top+1 == capacity){//checks if the capacity is the same as the top
    incCapacity();
	}
	top++;//increments the top of the array
	arr[top] = item; //sets the top of the array equal to the data being passed in 
}
/*Author: Sam Barnes
 * The purpose of this function is to remove data fromt the front of the
 * list and move everything else in the list up a spot. It passes a new variable
 * and stores the data popped there to delete it. The function is void and does not
 * return anything.*/
template <class T>//templates the pop function
void SUStackArr<T>::pop(T &item) {
	if(isEmpty()) {//if the function is empty
		std::cout << "The stack is empty\n";//display the stack is empty
	}
	else {//otherwise
		item = arr[top];//set the item equal to the top of the array
		top--;//decrement the top in order to move items down
	}
}
/*Author: Sam Barnes
 * This is the print stack function and it is su[pposed to print the
 * data that is currently inside of the stack. It is a void function and 
 * it does not take any parameters. It walsk through the array printing each spot.*/
template <class T>//templates the print stack function
void SUStackArr<T>::printStack() {
	std::cout << "===================\n";
	for(int i = 0; i < top+1; i++) {//loops through the array
		std::cout << arr[i] << std::endl;//prints the array in the ith position
	}
	std::cout << "===================\n";

}

/*Author: Sam Barnes
 * The purpose of this function is to get the size of the array and return that numbers
 * so that it can be used in other functions. It does not take parameters and returns an
 * int.*/
template <class T>//templates the size function
int SUStackArr<T>::size() {
	return top+1;//returns the top +1 because of the array off by 1 functionality
}
/*Author: Max Camm
 * The purpose of this function is to create a second array that holds the same value as the
 * first array. This weay you can modify the new one without changing the first array. It passes
 * in a object and returns a pointer.*/
template <class T>//templates the overloaded array function
SUStackArr<T>& SUStackArr<T>::operator=(const SUStackArr<T> &obj) {//Overloads the operator= to make new stack


	arr = new T[obj.capacity];
	top = obj.top;
	for(int i = 0; i < size() - 1; i++){
		arr[i] = obj.arr[i];
	}
}



/*
 *incCapacity function will be called from the push function. If the capacity is reached incCapacity
 *will be called. This function will allocate a new array with double the capacity and copy the old array
 *into the newly created array and deletes the old array
 *Author: Max Camm
*/
template <class T>
void SUStackArr<T>::incCapacity(){

	T* oldArray = arr;
	capacity *= 2;
	arr = new T[capacity];

	for(int i = 0; i < size(); i++){
		arr[i] = oldArray[i];
	}

	delete[] oldArray;
 }