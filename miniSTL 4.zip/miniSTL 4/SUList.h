//Samuel Barnes and Maxwell Camm


/******************************************************************
/*The doubly linked list is a abstract data type that stores      *
 * a list of elements. In this implementation, we use functions   *
 * to add to either the front or the back of the list, get the    *
 * front and back as well as keep track of its size and container *
 * functions                                                      *
 ******************************************************************/

#ifndef SULIST_H
#define SULIST_H
#include <iostream>
//templates the list class header file
template <class DataType>
class SUList{
private:
  struct ListNode{    //creates a node to store values
   DataType data;     //where the value of the node is stored
   ListNode* next;    //variable to point to the next item in the list
  };
  ListNode* head;     //points to the front of the list
  ListNode* tail;     //points to the rear of the list

public:
   SUList();                        //constructor
   SUList(const SUList&);           //copy constructor
   ~SUList();                       //destructor
   DataType getFront();             //gets the item at the front of the list
   DataType getBack();              //gets the item on the back of the list
   void putFront(const DataType&); // Add to the front
   void putBack(const DataType&);  // Add to the back
   int size() const;               // Returns the number of elements
   bool contains(const DataType&); // Tests for membership
   SUList& operator=(const SUList&);//creates a second list to hold values in the first list

};

#include "SUList.cpp"

#endif



