//Samuel Barnes
//computer science 220
//10/20/2017
//lab6
//sam barnes
#include <iostream>
using namespace std;
int partition(int arr[], int start, int end) {
  int pivot = start;
  int t = 0;
  for(int i = start; i < (end); i++ ) {
    //cout << arr[pivot] << endl;
    if(arr[pivot] > arr[i]) {
      cout << i << " " << pivot << endl;
      swap(arr[pivot], arr[pivot+1]);
      if(i != pivot +1) {
      swap(arr[pivot], arr[i]);
      }
      pivot++;
     
    }
  }
  return pivot;
}

void quickSort(int arr[], int start, int end) {
  if(start >= end)
    return;
  else {
   // cout << "fuck off2\n";
    int pivot = partition(arr, start, end);
   // cout << "fuck off3\n";
    quickSort(arr, start, pivot);
    quickSort(arr, pivot+1, end);
  }  
}
void swap(int &val1, int &val2) {
  int temp = 0;
  temp = val1;
  val1 = val2;
  val2 = temp;
}
int main() {
  int a = 10;
  int b = 5;
  int arr[] = {3, 5, 1, 6};
  //swap(arr[0], arr[1]);
  //swap(a, b);
  //cout << "a: " << a << " - " << "b: " << b <<endl;
  //print "a: 5 - b: 10
  //cout << arr[0] << "   " << arr[1] << endl; 
  quickSort(arr, 0, 4);
  for(int j = 0; j < 4; j++) {
    cout << arr[j] << endl;
  }
}