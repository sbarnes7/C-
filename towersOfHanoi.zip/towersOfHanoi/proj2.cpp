//Samuel Barnes
//Project 2 
//Towers of Hanoi
//10/23/2017
//This program is a towers of hanoi game that lest the user
//enter how many disks they would like to use and follows the
//rules of the game. The program also has a menu with a help
//option that steps you through the game of how to play.
#include<iostream>
#include<stdexcept>
//class that implements the stack functions
class HanoiStack {
  private:
    struct disk{
      double value;
      struct disk *next;
    };

    disk *head;
  
  public:
    HanoiStack(){ head = nullptr; }
    ~HanoiStack(){ };

    disk* findHead(){
      return head;
    }

    void push(double);
    double pop();
    void push2(double);
    double pop2();
    void push3(double);
    double pop3();
    void displayList() const;
    };
//function to push a number into a stack list
void HanoiStack::push(double x){
  disk* newNode = new disk;
  newNode->value = x;
  newNode->next = this->head;

  head = newNode;
}
//function to remove the top number from a stack
double HanoiStack::pop(){
  disk* oldNode = head;

  if(!head){
    std::cout << "The stack is empty :(" << std::endl;
    throw "Stack is empty";
    return 1;
  }

  double ret = oldNode->value;

  head = head->next;

  delete oldNode;
  return ret;
}
//function to display the current stack of the game
void HanoiStack::displayList() const{
  disk *cursor = this->head;

  std::cout << "=====================" << std::endl;
  while ( cursor != nullptr ){
    std::cout << cursor->value << std::endl;
    cursor = cursor->next;
  }
}
//function to run you through the actual game
void startGame() {
	  HanoiStack list1;
  HanoiStack list2;
  HanoiStack list3;
  int game = 0;
  int counter = 0;
  int towerNum = 0;
  int num = 0;
  
   int menuOption = 0;

	  std::cout << "How many disks would you like to play with?\n";
 		std::cin >> num;
		if(num > 8) {
			std::cout << "Pick a number smaller than 8\n";
			std::cin >> num;
		}
	    for(int i = num; i > 0; i--) {
		    list1.push(i);
	    }
    	    int tower = 0;
	do {
		counter++;
	std::cout << "List 1\n";
	list1.displayList();
	std::cout << "\n\nList 2\n";
	list2.displayList();
	std::cout << "\n\nList 3\n";
	list3.displayList();
	 std::cout << "Which tower would you like to remove from?(-1 to quit)\n";
            int newT = 0;
	    int popper = 0;
            std::cin >> tower;
	    if(tower == -1) {
		    break;
	    }
	    else if(tower > 3) {
		    std::cout << "Invalid input try agin\n";
		    std::cin >> tower;
	    }
            std::cout << "Which tower would you like to move it to?\n";
            std::cin >> newT;
            if(tower == 1) {
                if(newT == 2) {
			list2.push(list1.pop());
                }
                else if(newT == 3) {
                    list3.push(list1.pop());
                }
		else
			std::cout << "Invalid Input\n";              
            }
            else if(tower == 2) {
                if(newT == 1) {
                    list1.push(list2.pop());
                }
                else if(newT == 3) {
                    list3.push(list2.pop());
                }
		else
			std::cout << "Invalid input\n";
            }
            else if(tower == 3) {
                if(newT == 1)
                list1.push(list3.pop());
                else if(newT == 2)
                list2.push(list3.pop());
		else
			std::cout << "Invalid input\n";
            }
	    else {
		    std::cout << "That was not an option try again\n";
	    }
          
	} while(tower != -1);
	std::cout << "List 1\n";	
	list1.displayList();
	std::cout << "\n\nList 2\n";
	list2.displayList();
	std::cout << "\n\nList 3\n";
	list3.displayList();
	std::cout << "Congrats, it took you " << counter-1 << " moves to finish the game\n";
	std::cout << std::endl << std::endl;
}
//function for the settings that teaches you how to play the game
void help() {
	std::cout <<"==================================================\n"
		   << "The puzzle starts with the disks in a neat stack\n"
		   <<"in ascending order of size on one rod, the smallest\n"
		   <<"at the top, thus making a conical shape.\n"
		   <<"===================================================\n\n";
	int n=0;
	while (n != 3){
	std::cout <<"Choose one of the following\n" 
		<<"1.Rules\n2.Least number of moves for n disks\n3. Quit\n";
	std::cin >> n;
	if(n == 1) {
		std::cout << "==========================================================\n"
			  << "The objective of the puzzle is to move the entire stack\n"
		          << "to another rod, obeying the following simple rules:\n\n";
		std::cout << "1.Only one disk can be moved at a time.\n"
                          << "2.Each move consists of taking the upper disk from one of\n"
			  << "  the stacks and placing it on top of another stack.\n"
                          << "3.No disk may be placed on top of a smaller disk.\n"
			  << "==========================================================\n";
	}
	else if(n == 2) {
		std::cout << "===================\n"
			<<"3 Disks = 7   moves\n4 Disks = 15  moves\n5 Disks = 31  moves\n"
		       <<"6 Disks = 63  moves\n7 Disks = 127 moves\n8 Disks = 255 moves\n"
		       <<"===================\n";
	}
	else {
	break;
	}
	}	

}
//function that displays the start menu to play the game or learn how to play
int main(int argc, char* argv[]){
    int menuOption = 0;
    std::cout << "=======================\n";
    std::cout << "Welcome to the Program\nTOWERS OF HANOI\n";
    std::cout << "=======================\n";
    while(menuOption != 3) {
	    std::cout << "Please choose from the following:\n";
    std::cout << "1. New Game\n2. Help\n3. Quit\n";
    std::cin >> menuOption;
    if(menuOption == 1) {
	    startGame();
    }
    else if(menuOption == 2)
	    help();
    else
	    break;
    }
  return 0;

}
