//Max Camm and Sam Barnes
#ifndef SUQUEUE_H
#define SUQUEUE_H
#include "SUList.h"
#include <iostream>
/**********************************************************************************
 *The SUQueue database is a queue based database way iof storing variables into   *
 * a list. The way the queue is implemented is through the SUList class and calls *
 * putFront to add to the front of the queue and uses the getback to remove from  *
 * the back of the list. Queues are worked using a first in first out operation.  *
 * ********************************************************************************/
template <class DataType>//templates the list based implementation of the queue
class SUQueueList {
	private:
		SUList<DataType> list;
	public:
		SUQueueList(); // Constructor
		SUQueueList(const SUQueueList &); // Copy Constructor
		~SUQueueList(); // Destructor
		int size() const; // get the number of elements in the queue
		bool isEmpty() const; // Check if the queue is empty
		void enqueue(const DataType&); // Enqueues some data
		void dequeue(DataType&); // Get the front element and store it
		void printQueue() const; // Prints the queue from the front to the rear
		SUQueueList& operator=(const SUQueueList&);	// Assignment operator
};
template <class DataType>//implements the array based implementation of the queue
class SUQueueArr{
	private:
		DataType* arr;        // The array of items
		int       capacity = 10;   // The size of the current array
		int       front;      // The location of the front element
		int       rear;       // The location of the rear element
		void incCapacity();

	public:
		SUQueueArr();                   // Constructor
		SUQueueArr(const SUQueueArr &); // Copy Constructor
		~SUQueueArr();                  // Destructor
		int size() const;               // get the number of elements in the queue
		bool isEmpty() const;           // Check if the queue is empty
		void enqueue(const DataType&);  // Enqueues some data
		void dequeue(DataType&);        // Get the front element and store it
		void printQueue() const;        // Prints the queue from the front to the rear
		SUQueueArr<DataType>& operator=(const SUQueueArr<DataType>& obj) {
			arr = new DataType[obj.capacity];
			capacity = obj.capacity;
			front = obj.front;
			rear = obj.rear;
			for(int i = 0; i < capacity; i++){
				arr[i] = obj.arr[i];
			}
		}
		// Assignment operator
};


#include "SUQueue.cpp"
#endif

