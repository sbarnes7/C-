
#include "student.h"
#include <iostream>
#include <string>


Student::Student(){
    name = "";
    DOB = "";
    major = "";
}

Student::Student(std::string n, std::string d, std::string m){
    name = n;
    DOB = d;
    major = m;
}

Student::~Student(){

}

void Student::setName(std::string n){

	name = n;
}

void Student::setDOB(std::string d){

	DOB = d;
}

void Student::setMajor(std::string m){

	major = m;
}

void Student::sDisplay(){

    std::cout << "Name: " << name << std::endl;
    std::cout << "Date of Birth: " << DOB << std::endl;
    std::cout << "Major: " << major << std::endl;
}
