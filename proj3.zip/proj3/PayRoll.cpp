#include<iostream> // cout, endl
#include "PayRoll.h" // PayRoll
#include "PayRollQueue.h" // PayRollQueue

void printqueue(PayRollQueue<PayRoll>);


/**
 * Runs some simple tests with PayRoll and PayRollQueue before we have copy
 * constructors implemented.
 */
int main(){
  PayRollQueue<PayRoll> q;
  std::string testString;
  //double testDouble;
  int testInt;

  PayRoll tmp("Bob", 20, 10);
  PayRoll tmp2 = tmp;
  tmp2.setName("Alice");
  tmp2.setHours(30);

  PayRoll tmp3;
  tmp3.setHours(10);
  tmp3.setRate(40);
  tmp3.setName("Clara");

  // Queue the employees
  q.enqueue(tmp);
  q.enqueue(tmp2);
  q.enqueue(tmp3);

  // The first one we queued was Bob
  testString = q.dequeue().getName();
  if( testString != "Bob" ){
    std::cout << "Dequeue test failed.\n";
  } else {
    std::cout << "Deqeue Test 1 passed...\n";
  }
  std::cout << "Expected: Bob\n";
  std::cout << "Observed: " << testString << std::endl;
  std::cout << "=========================\n";

  // Queue a few more items
  q.enqueue(tmp2);
  q.enqueue(tmp);

  // THe second one we queued was Alice
  testString = q.dequeue().getName();
  if( testString != "Alice" ){
    std::cout << "Dequeue Test 2 failed.\n";
  } else {
    std::cout << "Deqeue Test 2 passed...\n";
  }
  std::cout << "Expected: Alice\n";
  std::cout << "Observed: " << testString << std::endl;
  std::cout << "=========================\n";

  // The length of q should be 3
  testInt = q.length();
  if( testInt != 3 ){
    std::cout << "length() Test 1 failed.\n";
  } else {
    std::cout << "length() Test 1 passed...\n";
  }
  std::cout << "Expected: 3\n";
  std::cout << "Observed: " << testInt << std::endl;
  std::cout << "=========================\n";
  
  // Print the full queue by dequeueing
  std::cout << "+++++ TEST printqueue(q) +++++\n";
  printqueue(q);
  std::cout << "+++++ TEST printqueue(q) FINISHED +++++\n";

  // The length of q should not have been changed since printqueue
  // takes a copy of it, before dequeuing
  testInt = q.length();
  if( testInt != 3 ){
    std::cout << "length() Test 2 failed.\n";
  } else {
    std::cout << "length() Test 2 passed...\n";
  }
  std::cout << "Expected: 3\n";
  std::cout << "Observed: " << testInt << std::endl;
  std::cout << "=========================\n";

  PayRollQueue<PayRoll> q2 = q;
  q2.enqueue(PayRoll("Eve", 5,5));

  testInt = q.length();
  if( testInt != 3 ){
    std::cout << "length() Test 3 failed.\n";
  } else {
    std::cout << "length() Test 3 passed...\n";
  }
  std::cout << "Expected: 3\n";
  std::cout << "Observed: " << testInt << std::endl;
  std::cout << "=========================\n";

  testInt = q2.length();
  if( testInt != 4 ){
    std::cout << "length() Test 4 failed.\n";
  } else {
    std::cout << "length() Test 4 passed...\n";
  }
  std::cout << "Expected: 4\n";
  std::cout << "Observed: " << testInt << std::endl;
  std::cout << "=========================\n";

  PayRollQueue<PayRoll> q3;
  q3.enqueue(PayRoll("Bob Loblaw", 100, 20));
  q3.enqueue(PayRoll("Foo", 10, 20));
  q3.enqueue(PayRoll("Bar", 100, 2));

  q = q3;

  printqueue(q);

  testInt = q.length();
  if( testInt != 3 ){
    std::cout << "length() Test 5 failed.\n";
  } else {
    std::cout << "length() Test 5 passed...\n";
  }
  std::cout << "Expected: 3\n";
  std::cout << "Observed: " << testInt << std::endl;
  std::cout << "=========================\n";

  // Should dequeue Bob Loblaw
  testString = q.dequeue().getName();
  if( testString != "Bob Loblaw" ){
    std::cout << "Dequeue Test 3 failed.\n";
  } else {
    std::cout << "Deqeue Test 3 passed...\n";
  }
  std::cout << "Expected: Bob Loblaw\n";
  std::cout << "Observed: " << testString << std::endl;
  std::cout << "=========================\n";

  // Should dequeue Bob Loblaw again
  testString = q3.dequeue().getName();
  if( testString != "Bob Loblaw" ){
    std::cout << "Dequeue Test 4 failed.\n";
  } else {
    std::cout << "Deqeue Test 4 passed...\n";
  }
  std::cout << "Expected: Bob Loblaw\n";
  std::cout << "Observed: " << testString << std::endl;
  std::cout << "=========================\n";



  return 0;
}

// Prints a queue by dequeuing
// Note: *should* not affect the parameter after we have a proper
// copy ctor, we're passing by value!
// But before a copy ctor, copies the same "head" address

void printqueue(PayRollQueue<PayRoll> q){
  while(q.length() > 0){
    q.dequeue().printCheck();
  }
}

/********* OUTPUT OF THIS PROGRAM ***********

Deqeue Test 1 passed...
Expected: Bob
Observed: Bob
=========================
Deqeue Test 2 passed...
Expected: Alice
Observed: Alice
=========================
length() Test 1 passed...
Expected: 3
Observed: 3
=========================
+++++ TEST printqueue(q) +++++
IN COPY CONSTRUCTOR
=======================
Name: Clara
Rate: 40
Hours:  10
Total:  400
=======================
Name: Alice
Rate: 10
Hours:  30
Total:  300
=======================
Name: Bob
Rate: 10
Hours:  20
Total:  200
+++++ TEST printqueue(q) FINISHED +++++
length() Test 2 passed...
Expected: 3
Observed: 3
=========================
IN COPY CONSTRUCTOR
length() Test 3 passed...
Expected: 3
Observed: 3
=========================
length() Test 4 passed...
Expected: 4
Observed: 4
=========================

*/
