//Samuel Barnes and Max Camm
//Samuel Barnes and Max Camm
/****************************************************************
 *Implementation of the functions from the SUList header file   * 
 * are implemented here. Each function is documented properly   * 
 * as well as listing the author of the functions. The get      * 
 * front and get back functions are implemented to remove from  *
 *the list when the function is called as well.                 *
 ****************************************************************/ 



#include "SUList.h"
/* Author: Max Camm
 * templates the overloaded operator= assignment operator allowing a second
 * list to be made and copies the values from the first list into the second.
 */
template<class DataType>//templates the overloaded function
SUList<DataType>& SUList<DataType>::operator= (const SUList<DataType>& other){
    ListNode* cursor = new ListNode;//creates a new pointer variable to run through list
    ListNode* temp;//creates a temp to store the value of cursor
    //if pointer does not equal the new object
    if(this != &other){
	cursor = head;//sets cursor equal to the head of the list
	while(cursor != nullptr){//while cursor does not reach end of the list
	  temp = cursor;//set temp equal to the cursor
	  cursor = cursor->next;//move cursor to next spot in the list
	  delete temp;//delete the temp variable freeing memory
	}

	head = nullptr;//sets head of the list equal to nullptr
	cursor = other.head;//sets cursor equal to new lists head

	while(cursor){//while cursor can move through the list
	    putBack(cursor->data);//put the data held into the back of the list
	    cursor = cursor->next;//move cursor to the next spot
	}

    }
    return *this;//return the pojnter to the object
}
/*Author: Max Camm
 * Function is meant to pass in a new value of type datatype and store
 * it into the back of the list. Function is void and does not return anything.
 */
template<class DataType>//templates the putback function
void SUList<DataType>::putBack(const DataType& newValue){

  ListNode* cursor = new ListNode;//creates a cursor pointer
  ListNode* newNode = new ListNode;//creates a new node pointer
  newNode->data = newValue;//stores data passed in intot he newnodes data
  cursor = head;//sets the cursor to the head of the list

    if(head == nullptr){//if head is the back of the list
        newNode->next = nullptr;//set the next node equal to nullptr
        head = newNode;//set the head equal to the newnode
        tail = newNode;//sets tail equal to newnode as well

    }
    else{//otherwise

        while(cursor->next != nullptr){//until cursor equals nullptr
        cursor = cursor->next;//move cursor to the next node repeatedly
        }

    cursor->next = newNode;//sets the last spot of the list to new data
    newNode->next = nullptr;//makes end of the list move down and sets to nullptr
    tail = newNode;//sets tail equal to the newnode
    }
}
/*Author: Max Camm
 * The purpose of this function is to add a item to the front of 
 * the list and move everything else down one spot towards the back.
 * It is a void function and has a parameter of datatype.*/
template<class DataType>//templates the putfront function
void SUList<DataType>::putFront(const DataType& newValue){
    ListNode* newNode = new ListNode;//creates a new node to hold values
    newNode->data = newValue;//set data of the new node equal to passed in value

    if(head == nullptr){//if head equals the nullptr
      head = newNode;//sets the head of the list equal to the new node
      newNode->next = nullptr;//sets the next node equal to nullptr
      tail = newNode;//sets the tail equal tot he nullptr
    }
    else{//otherwise
      newNode->next = head;//set next node equal to head
      head = newNode;//set head equal to the new node
    }
}

/*Author: Max Camm
 * This function has a purpose of getting and returning the data that is stored in
 * the front of the list. When returning this data it also deletes it from the list
 * as well. It returns a datatype and does not take any fucntion parameters.*/
template<class DataType>//templates the get front function
DataType SUList<DataType>::getFront(){
  ListNode* node = new ListNode;//creates a pointer node
  node = head;//set6s the pointer node equal to head
  DataType t;//creates new datatype variable

  if(head == nullptr){//if head equals nullptr
    std::cout << "list is empty" << std::endl;//print the list is empty
    return t;//return the new variable
  }
  else{//otherwise
    head = head->next;//set head equal to the next node in list
    return node->data;//return the data in the created node
  }
}
 /*Author: Max Camm
  * This function serves its purpose of finding the back of the list
  * and returning the data stored in the back of the list. When returning
  * this data, it is also deleted from the list. It returns a datatype
  * and does not takle any parameters.*/
template<class DataType>
DataType SUList<DataType>::getBack() {
  ListNode* end = new ListNode;//creates a new node for the end
  ListNode* prev = new ListNode;//another new node for the one before end
  prev = head;//set previous equal to the head of the list
  end = head;//set end equal to the head
  DataType t;//create a new datatype variable named t


  if(head == nullptr){//if the head is a nullptr
    std::cout << "list is empty" << std::endl;//display the list is empty
    DataType temp;//create the temp variable
    return temp;//return the created temp variable
  }
  else{//otherwise

    while(end->next != nullptr){//step through list to get to end 
      prev = end;
      end = end->next;//move to bnext node in list
    }

    t = end->data;//set t = to the data at enhd of list

    if(head == tail){//if head is same as tail
      head = nullptr;//head is nullptr
      tail = nullptr;//tail is nullptr
      delete end;//delete whats on the end of the list
    }
    else{//otherwise
      prev->next = nullptr;//set next equal to nullptr
      tail = prev;//set the tail to one before the end
      delete end;//delete the end
    }
    return t;//return the t variable
  }

}
/*Author: Max Camm
 * This is the destructor of the list and its purpose is to delete
 * the list when it is done being used to free up memory. No return
 * type and no parameters.*/
template<class DataType>//templates the destructor
SUList<DataType>::~SUList(){

	ListNode* nodeptr;//creates a pointer variable for nodes
	ListNode* temp;//creates a temp to store data
	nodeptr = head;//sets the node equal to the head of the list
	while(nodeptr != nullptr){//while you arent at the end of the list
		temp = nodeptr;//temp equals the nodeptr
    nodeptr = nodeptr->next;//move nodeptr to next node
    delete temp;//delete value in temp
  }
}

/*Author: Sam Barnes
 * The constructor is meant to intialize all the private variables
 * being used for the class. No return type and no parameters.*/
template<class DataType>//templates the constructor
SUList<DataType>::SUList(){
	head = nullptr;//sets head equal to the nullptr
  tail = nullptr;//sets tail equal to nullptr
}
/*Author: Max Camm
 * This is the copy constructor and the purpose of this is to create a 
 * new list and store the sme values from the first list into the second
 * list in otrder to maske changes to one list without changing the other list.
 Passes in an object and returns the data type*/
template<class DataType>//templates the copy constructor
SUList<DataType>::SUList(const SUList& other){

    ListNode* cursor = new ListNode;//creates a cursor node
    cursor = other.head;//sets cursor equal to the second list cursor
    head = nullptr;//sets head equal to nullptr

    while(cursor != nullptr){//move cursor throug the list
        putBack(cursor->data);//put data into the back of the list
        cursor = cursor->next;//move cursor over
    }
}
/*Author: Max Camm
 * The purpose of this function is to determine the size of
 * the list and store that number in order to use it in other'
 * functions when necessary. No param,eters and returns an int
 * holding the size of the list*/
template<class DataType>//templates the size function
int SUList<DataType>::size() const{
	ListNode* nodeptr = new ListNode;//creates a nodeptr 
  nodeptr = head;//sets the pointer equal to head of the list
	int counter = 0;//creates a counter variable to count nodes
	while(nodeptr != nullptr){//step through the list
		nodeptr = nodeptr->next;//move nodeptr over
		counter++;//increment the counter variable
	}
	return counter;//return the size of the list
}
/*Author: Max Camm
 * The purpose of this function is to determine if a certain data is contained 
 * inside of the list. It searches through the list comparing the parameter to 
 * a node and returns a true when found or false if it gets to tail or nullptr.
 * Takes a itema and returns a boolean true or false.*/
template<class DataType>//templates the contains function
bool SUList<DataType>::contains(const DataType& member){
	ListNode* value = new ListNode;//a node to hold a value
	while(value != nullptr){//steps through the list
		if(value == member){//if there is a match of member and the nodes value
			return true;//return true
		}
		else{//otherwise
			value = value->next;//move to the next spot in the list
		}
	}
	return false;//if made it this far return false and data is not found
}


