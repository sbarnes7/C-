#ifndef PAYROLL_H
#define PAYROLL_H
#include <iostream>
//Sam Barnes
class PayRoll {

                 private:
			 std::string name;
                   double rate;
                   double hours;
                 public:
                   double getTotal() {
  return rate * hours;
  }
		   void printCheck();
  PayRoll();
  PayRoll(std::string, double, double);
  PayRoll(const PayRoll&);

                   double getRate() {
  return rate;
  }
                   double getHours() {
  return hours;
  }
                   void setRate(double r) {
  rate = r;
  }
                   void setName(std::string n) {
  name = n;
  }
                   void setHours(double hr) {
  hours = hr;
  }
		   std::string getName() {
  return name;
  }
  friend std::ostream& operator<<(std::ostream&, const PayRoll);
		  // PayRoll(std::string, double, double);
};

std::ostream& operator<<(std::ostream& o, const PayRoll other){
  o << "In operator<< PayRoll\n";
  o << "Name: "<<other.name << std::endl <<"Rate: " <<other.rate << std::endl <<"Hours: " << 
		other.hours << std::endl << "Total: " << other.rate*other.hours << std::endl;
		return o;
  
}
PayRoll::PayRoll() {
    
  }
  PayRoll::PayRoll(std::string n, double r, double hr) {
   name = n;
   rate = r;
   hours = hr;
  }
void PayRoll::printCheck() {
	std::cout << "===================\n";
	std::cout << "Name: "<<name << std::endl <<"Rate: " <<rate << std::endl <<"Hours: " << 
		hours << std::endl << "Total: " << rate*hours << std::endl;
	std::cout << "===================\n";
}
  PayRoll::PayRoll(const PayRoll& other) {
     std::cout << "IN COPY CTOR\n";
     
    name = other.name;
    rate=other.rate;
    hours = other.hours;
    
  }
  

#endif




