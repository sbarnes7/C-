#include <iostream>
#include <string>

#ifndef STUDENT_H
#define STUDENT_H


class Student{

private:
	std::string name;
	std::string DOB;
	std::string major;

public:
    inline Student();
    inline Student(std::string, std::string, std::string);
    inline ~Student();
	inline void setName(std::string);
	inline void setDOB(std::string);
	inline void setMajor(std::string);
	inline void sDisplay();

};

#endif
