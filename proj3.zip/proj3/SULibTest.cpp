#include<iostream>
#include "SUList.h"
#include "SUStack.h"
#include "PayRoll.h"
#include "SUQueue.h"

/**
 * This program provides a slightly-more-than-minimal
 * example of a program that makes use of the various
 * classes defined in the SULibrary project.
 *
 * It only runs partial tests for three of the classes.
 * You should write more on your own, but this can
 * server as a sanity-check to get started.
 *
 * Be sure to think about edge cases!
 */

int main(){

  /*
   * First, make sure our templates are available.
   */

  SUList<int> myList;
  SUList<PayRoll> pList;

  //SUStackArr<int> iStackArr;
  //SUStackArr<PayRoll> pStackArr;
  SUStackList<int> iStackList;
  SUStackList<PayRoll> pStackList;

  SUQueueArr<int> iQueueArr;
  SUQueueArr<PayRoll> pQueueArr;
  SUQueueList<int> iQueueList;
  SUQueueList<PayRoll> pQueueList;

  /**
   * Test the SUList using ints
   */
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";


  myList.putFront(1);
  myList.putFront(2);
  myList.putBack(3);
  myList.putBack(4);
  myList.putFront(5);


  std::cout << "==========================\n";
  std::cout << "SUList<int> size: " << myList.size() << std::endl;


  std::cout << myList.getFront() << std::endl;
  std::cout << myList.getFront() << std::endl;
  std::cout << myList.getBack() << std::endl;
  std::cout << myList.getBack() << std::endl;
  std::cout << myList.getBack() << std::endl;






  /**
   * Test the SUList using PayRoll
   */
  pList.putFront(PayRoll("Bob", 20, 35));
  pList.putFront(PayRoll("Alice", 10, 35));
  pList.putBack(PayRoll("Charlie", 25, 35));
  pList.putBack(PayRoll("Diana", 10, 35));
  pList.putFront(PayRoll("Eve", 30, 35));

  std::cout << "==========================\n";
  std::cout << "\n\nSUList<PayRoll> size: " << pList.size() << std::endl;

  //uses getFront and getBack to test if putFront and putBack functions are working properly
  std::cout << "pList<PayRoll> Front: \n" << pList.getFront() << std::endl;
  std::cout << "pList<PayRoll> Back: \n" << pList.getBack() << std::endl;




  /*
   * Test the SUStack using PayRoll
  */
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";

   iStackList.push(1);
   iStackList.push(2);
   iStackList.push(3);
   iStackList.push(4);
   iStackList.push(5);
   iStackList.push(6);


  std::cout << "==========================\n";
  std::cout << "SUStackList<int> size: " << iStackList.size() << std::endl;
  iStackList.printStack();


  pStackList.push(PayRoll("Bob", 20, 35));
  pStackList.push(PayRoll("Alice", 20, 35));
  pStackList.push(PayRoll("Charlie", 20, 35));
  pStackList.push(PayRoll("Diana", 20, 35));
  pStackList.push(PayRoll("Eve", 20, 35));



  std::cout << "==========================\n";
   std::cout << "\n\nSUStackList<PayRoll> size: " << pStackList.size() << std::endl;
  pStackList.printStack();



  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";

  int num;
  iQueueList.enqueue(1);
  iQueueList.enqueue(2);
  iQueueList.enqueue(3);
  iQueueList.enqueue(4);
  iQueueList.enqueue(5);
  iQueueList.dequeue(num);
  iQueueList.dequeue(num);
  iQueueList.dequeue(num);
  iQueueList.enqueue(1);
  iQueueList.enqueue(2);
  iQueueList.enqueue(3);

  std::cout << "==========================\n";
  std::cout << "SUQueueList<int> size: " << iQueueList.size() << std::endl;

  iQueueList.printQueue();

  pQueueList.enqueue(PayRoll("Bob", 20, 35));
  pQueueList.enqueue(PayRoll("Alice", 20, 35));
  pQueueList.enqueue(PayRoll("Charlie", 20, 35));
  pQueueList.enqueue(PayRoll("Diana", 20, 35));
  pQueueList.enqueue(PayRoll("Eve", 20, 35));

  std::cout << "\n\n\n==========================\n";
  std::cout << "SUQueueList<PayRoll> size: " << iQueueList.size() << std::endl;
  
  pQueueList.printQueue();
  std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n\n";


  //iQueueArr.dequeue(num);
  int x;
  //iQueueArr.enqueue(1);
  //iQueueArr.enqueue(2);
  iQueueArr.enqueue(3);
  iQueueArr.enqueue(4);
  iQueueArr.enqueue(5);
  iQueueArr.enqueue(6);
  iQueueArr.enqueue(7);
  iQueueArr.enqueue(8);
  iQueueArr.enqueue(9);
  iQueueArr.enqueue(10);
  iQueueArr.enqueue(11);
  iQueueArr.enqueue(12);
  iQueueArr.enqueue(13);
  iQueueArr.enqueue(14);
  iQueueArr.enqueue(15);
  iQueueArr.enqueue(16);
  iQueueArr.enqueue(17);
  iQueueArr.enqueue(18);
  iQueueArr.enqueue(19);
  iQueueArr.enqueue(20);
  iQueueArr.enqueue(21);
  iQueueArr.printQueue();

  std::cout << "END MAIN" << std::endl;
  return 0;
}

/** OUTPUT OF THIS PROGRAM

3
2
6
1
4
5
++++++++++++
=======================
Name: Eve
Rate: 35
Hours:	30
Total:	1050

=======================
Name:	Alice
Rate:	35
Hours:	10
Total:	350

=======================
Name:	Bob
Rate:	35
Hours:	20
Total:	700

=======================
Name:	Charlie
Rate:	35
Hours:	25
Total:	875

=======================
Name:	Diana
Rate:	35
Hours:	10
Total:	350

++++++++++++
=======================
Name:	Eve
Rate:	35
Hours:	20
Total:	700

*/
