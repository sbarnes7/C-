//Sam Barnes and Max Camm
#ifndef SUSTACK_H
#define SUSTACK_H
#include "SUList.h"
#include <iostream>
//******************************************************************************
/*In computer science, a stack is an abstract data type that serves as           *
  a collection of elements, with two basic operations:                           *
    push, which adds an element to the collection, and                           *
    pop, which removes the most recently added element that was not yet removed. *
The order in which elements come off a stack gives rise to its alternative name, *
LIFO (last in, first out).                                                       *
*********************************************************************************/

/***********************
 * Stack List Template *
 * ********************/
template <class DataType>
class SUStackList{
	private:
		SUList<DataType> list;
	public:
		SUStackList();//Constructor
		SUStackList(const SUStackList &); // Copy Constructor
		~SUStackList();//Destructor
		int size() const;//get the number of elements in the stack
		bool isEmpty();//Check if the stack is empty
		void push(const DataType&);//Pushes an object onto the stack
		void pop(DataType&);//Pop an object off the stack
		void printStack();//Prints the stack from the top, down
		SUStackList& operator=(const SUStackList&);//Overloads the operator= to make new stack
};
/*************************
 * Stack Array Template  *
 * ***********************/
template <class DataType>
class SUStackArr{
	private:
		DataType* arr;   // The array of items
		int capacity;    // The size of the current array
		int top;         // The location of the top element
		//int stackSize;

	public:
		SUStackArr();                     // Constructor
		SUStackArr(const SUStackArr &);   // Copy Constructor
		~SUStackArr();                    // Destructor
		int size() ;                      // get the number of elements in the stack
		bool isEmpty();                   // Check if the stack is empty
		void push(const DataType&);       // Pushes an object onto the stack
		void pop(DataType&);              // Pop an object off the stack and store it
		void printStack();                // Prints the stack from the top, down
		SUStackArr& operator=(const SUStackArr&); //Overloaded function to make new stack
};
#include "SUStack.cpp"
#endif
